/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import {
  Code,
  Settings,
  Edit3,
  MapPin,
  Calendar,
  Github,
  Linkedin,
  Mail,
  BookOpen,
  Trophy,
  Zap,
  Target,
  ChevronRight,
  Award,
  TrendingUp
} from 'lucide-react';
import api from '../api/api';

const getUserIdFromToken = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;
  const payload = token.split('.')[1];
  const decoded = JSON.parse(atob(payload.replace(/-/g, '+').replace(/_/g, '/')));
  return decoded.userId;
};

const AccountPage = () => {
  const userId = getUserIdFromToken();

  const [profile, setProfile] = useState(null);
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (!userId) return;

    const fetchData = async () => {
      try {
        const [profileRes, recentRes] = await Promise.all([
          api.get(`/profile/${userId}`),
          api.get(`/profile/${userId}/recent`)
        ]);

              console.log("RECENT API RESPONSE:", recentRes.data);

        setProfile(profileRes.data);
        setRecent(recentRes.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [userId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-pink-700 flex items-center justify-center">
        <div className="text-white text-lg font-semibold flex items-center gap-2">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
          Loading profile…
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-pink-700 flex items-center justify-center">
        <div className="text-white text-lg">Profile not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-pink-700">
      <div className="bg-purple-900/60 backdrop-blur-xl border-b border-pink-500/30 shadow-2xl">
        <div className="max-w-7xl mx-auto px-6 h-16 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-pink-500 to-purple-500 rounded-xl shadow-lg shadow-pink-500/50">
              <Code className="text-white" size={20} />
            </div>
            <span className="text-xl font-bold text-white">CodeMaster</span>
          </div>
          <button className="p-2 hover:bg-purple-800/50 rounded-lg transition-all">
            <Settings className="text-white" size={20} />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        <div className="bg-purple-900/40 backdrop-blur-md border border-purple-500/30 rounded-2xl p-8 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-pink-500/20 to-purple-500/20 rounded-full blur-3xl -z-10"></div>
          
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 bg-gradient-to-br from-pink-500 to-purple-500 rounded-2xl flex items-center justify-center shadow-lg shadow-pink-500/50">
                <span className="text-4xl font-bold text-white">
                  {profile.username?.[0]?.toUpperCase() || 'U'}
                </span>
              </div>

              <div>
                <h1 className="text-3xl font-bold text-white mb-1">{profile.username}</h1>
                <p className="text-purple-200 mb-3 flex items-center gap-2">
                  <Mail size={16} />
                  {profile.email}
                </p>

                <div className="flex gap-6 text-sm text-purple-200">
                  <span className="flex items-center gap-2 bg-purple-800/30 px-3 py-1.5 rounded-lg">
                    <MapPin size={14} /> {"India"}
                  </span>
                </div>
              </div>
            </div>

            <button className="p-2 bg-purple-800/50 hover:bg-purple-700/50 rounded-lg transition-all">
              <Edit3 className="text-white" size={18} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          <Stat label="Solved" value={profile.solved} icon={BookOpen} color="from-emerald-500 to-teal-500" />
          <Stat label="Rating" value={`#${profile.rank}`} icon={Trophy} color="from-amber-500 to-orange-500" />
          <Stat label="Streak" value={`${profile.streak}`} icon={Zap} color="from-purple-500 to-pink-500" />
          <Stat label="Acceptance" value={`${profile.acceptanceRate}%`} icon={Target} color="from-blue-500 to-cyan-500" />
        </div>

        <div className="bg-purple-900/40 backdrop-blur-md border border-purple-500/30 rounded-2xl shadow-xl overflow-hidden">
          <div className="border-b border-purple-500/30 px-6 py-4">
            <h2 className="font-semibold text-white text-lg flex items-center gap-2">
              <TrendingUp size={20} className="text-pink-400" />
              Recent Activity
            </h2>
          </div>

          {recent.length === 0 ? (
            <div className="p-8 text-center text-purple-200">
              <div className="w-16 h-16 bg-purple-800/50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Code size={24} className="text-purple-300" />
              </div>
              <p>No submissions yet</p>
              <p className="text-sm text-purple-300 mt-1">Start solving problems to see your activity!</p>
            </div>
          ) : (
            <div className="divide-y divide-purple-500/20">
              {recent.map((r) => (
                <div
                  key={r.problemId}
                  className="flex justify-between items-center px-6 py-4 hover:bg-purple-800/30 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-2 h-2 rounded-full ${
                      r.status === 'Accepted' ? 'bg-emerald-400' : 
                      r.status === 'Wrong Answer' ? 'bg-rose-400' : 
                      'bg-amber-400'
                    }`}></div>
                    <span className="font-medium text-white">{r.title}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-sm px-3 py-1 rounded-full ${
                      r.status === 'Accepted' 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' 
                        : r.status === 'Wrong Answer'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-400/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                    }`}>
                      {r.status}
                    </span>
                    <ChevronRight className="text-purple-300 group-hover:translate-x-1 transition-transform" size={18} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-purple-900/40 backdrop-blur-md border border-purple-500/30 rounded-2xl p-6 shadow-xl">
          <h2 className="font-semibold text-white text-lg mb-4">Connect</h2>
          <div className="flex gap-3">
            <button className="p-3 bg-purple-800/50 hover:bg-purple-700/50 rounded-lg transition-all hover:scale-105">
              <Github className="text-white" size={20} />
            </button>
            <button className="p-3 bg-purple-800/50 hover:bg-purple-700/50 rounded-lg transition-all hover:scale-105">
              <Linkedin className="text-white" size={20} />
            </button>
            <button className="p-3 bg-purple-800/50 hover:bg-purple-700/50 rounded-lg transition-all hover:scale-105">
              <Mail className="text-white" size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Stat = ({ label, value, icon: Icon, color }) => (
  <div className="bg-purple-900/40 backdrop-blur-md border border-purple-500/30 rounded-2xl p-6 shadow-xl hover:scale-105 transition-all group relative overflow-hidden">
    <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-10 transition-opacity`}></div>
    <div className="relative flex justify-between items-start">
      <div>
        <p className="text-3xl font-bold text-white mb-1">{value}</p>
        <p className="text-sm text-purple-200">{label}</p>
      </div>
      <div className={`p-3 bg-gradient-to-br ${color} rounded-xl shadow-lg`}>
        <Icon className="text-white" size={20} />
      </div>
    </div>
  </div>
);

export default AccountPage;
