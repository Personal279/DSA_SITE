/* eslint-disable no-unused-vars */

import React, { useState, useEffect, useRef } from 'react'
import {
  Play, Target, Cpu, ArrowUp, Loader2, Code2, Terminal,
  CheckCircle2, XCircle, Sparkles, FlaskConical, Award
} from 'lucide-react'
import { useLocation } from 'react-router-dom'
import api from '../api/api'

export default function HomePage() {
  const location = useLocation()
  const problem = location.state

  const testCases = problem.testCases
  const hiddenCases = problem.hiddenCases

  /* ---------- STATIC TEMPLATES (ONLY C++) ---------- */
  const cppTemplate = `#include <iostream>
using namespace std;

class Solution {
public:
    void solve() {
        
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    Solution s;
    s.solve();
    return 0;
}`

  /* ---------- STATE ---------- */
  const [isMobile, setIsMobile] = useState(false)
  const [language, setLanguage] = useState('java')
  const [code, setCode] = useState('')
  const [testResults, setTestResults] = useState(null)
  const [isRunning, setIsRunning] = useState(false)
  const [leftWidth, setLeftWidth] = useState(40)
  const [isDragging, setIsDragging] = useState(false)
  const [resultsHeight, setResultsHeight] = useState(40)
  const [isDraggingVertical, setIsDraggingVertical] = useState(false)
  const [activeLeftTab, setActiveLeftTab] = useState('description')
  const [submissionResults, setSubmissionResults] = useState(null)
  const [showFlowers, setShowFlowers] = useState(false)

  const containerRef = useRef(null)
  const rightPanelRef = useRef(null)

  /* ---------- RESPONSIVE ---------- */
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768)
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  useEffect(() => {
  const fetchBoilerplate = async () => {
    try {
      const res = await api.get(
        `/api/problems/${problem.id}/boilerplate/java`
      )
      setCode(res.data)
    } catch (e) {
      setCode('// Failed to load boilerplate')
    }
  }

  if (language === 'java') {
    fetchBoilerplate()
  }
}, [language, problem.id])


  useEffect(() => {
    const handleMove = (e) => {
      if (isDragging && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect()
        const w = ((e.clientX - rect.left) / rect.width) * 100
        if (w > 20 && w < 80) setLeftWidth(w)
      }

      if (isDraggingVertical && rightPanelRef.current) {
        const rect = rightPanelRef.current.getBoundingClientRect()
        const h = ((rect.bottom - e.clientY) / rect.height) * 100
        if (h > 15 && h < 70) setResultsHeight(h)
      }
    }

    const stop = () => {
      setIsDragging(false)
      setIsDraggingVertical(false)
    }

    if (isDragging || isDraggingVertical) {
      document.addEventListener('mousemove', handleMove)
      document.addEventListener('mouseup', stop)
    }

    return () => {
      document.removeEventListener('mousemove', handleMove)
      document.removeEventListener('mouseup', stop)
    }
  }, [isDragging, isDraggingVertical])

  const getUserIdFromToken = () => {
    const token = localStorage.getItem('token')
    if (!token) return null
    const payload = JSON.parse(atob(token.split('.')[1]))
    return payload.userId
  }
  const handleRunTests = async () => {

     if (!problem || !problem.id) {
    alert("Problem ID missing. Please reopen the problem.");
    return;
  }
    setIsRunning(true)
    try {
      const res = await api.post('/api/run', {
        problemId: problem.id,
        language,
        code,
        showDiff: true,
      })
      setTestResults(res.data)
    } catch {
      setTestResults('ERROR contacting judge')
    }
    setIsRunning(false)
  }

  const handleSubmit = async () => {
    setIsRunning(true)
    setShowFlowers(false)

    const userId = getUserIdFromToken()
    if (!userId) {
      setSubmissionResults('USER_NOT_LOGGED_IN')
      setActiveLeftTab('results')
      setIsRunning(false)
      return
    }
    try {
      const res = await api.post('/api/submit', {
        userId,
        problemId: problem.id,
        language,
        code,
      })

      setSubmissionResults(res.data)
      setActiveLeftTab('results')

      if (res.data === 'ALL_TESTS_PASSED') {
        setShowFlowers(true)
        setTimeout(() => setShowFlowers(false), 5000)
      }
    } catch {
      setSubmissionResults('ERROR contacting judge')
      setActiveLeftTab('results')
    }

    setIsRunning(false)
  }

  const handleLanguageChange = (lang) => {
    setLanguage(lang)
    if (lang === 'cpp') setCode(cppTemplate)
  }
  return (
    <div className="h-screen w-screen overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white flex flex-col">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-purple-700/10 via-transparent to-transparent pointer-events-none"></div>
      
      {showFlowers && (
        <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="flower absolute animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${3 + Math.random() * 2}s`
              }}
            >
              🌸
            </div>
          ))}
        </div>
      )}
      
      <header className="relative z-10 flex justify-between items-center px-6 py-3 bg-white/5 backdrop-blur-xl border-b border-white/10">
        <div className="flex gap-3 items-center">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-lg bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">Coding Master</h1>
            <p className="text-xs text-purple-300/60 flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              Solve & Conquer
            </p>
          </div>
        </div>

        <div className="flex gap-2 items-center">
          <div className="flex gap-1 bg-white/5 rounded-lg p-1 border border-white/10">
            <button
              onClick={() => handleLanguageChange('java')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-300 ${
                language === 'java'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                  : 'text-purple-200/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Java
            </button>
            <button
              onClick={() => handleLanguageChange('cpp')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-300 ${
                language === 'cpp'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                  : 'text-purple-200/60 hover:text-white hover:bg-white/5'
              }`}
            >
              C++
            </button>
          </div>

          <button
            onClick={handleRunTests}
            disabled={isRunning}
            className="group relative overflow-hidden bg-emerald-500/90 hover:bg-emerald-500 px-4 py-2 rounded-lg flex gap-2 items-center font-medium text-sm transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/40 hover:scale-105 active:scale-95"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/20 to-green-400/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            {isRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            <span className="relative">Run</span>
          </button>

          <button
            onClick={handleSubmit}
            disabled={isRunning}
            className="group relative overflow-hidden bg-gradient-to-r from-purple-500 to-pink-500 px-4 py-2 rounded-lg flex gap-2 items-center font-medium text-sm transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-pink-500/20 hover:shadow-pink-500/40 hover:scale-105 active:scale-95"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600/50 to-pink-600/50 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <ArrowUp className="w-4 h-4 relative" />
            <span className="relative">Submit</span>
          </button>
        </div>
      </header>

      <div ref={containerRef} className="flex-1 flex relative overflow-hidden">
        <div
          className="flex flex-col bg-white/5 backdrop-blur-sm border-r border-white/10"
          style={{ width: `${leftWidth}%` }}
        >
          <div className="flex border-b border-white/10 bg-white/5">
            <button
              onClick={() => setActiveLeftTab('description')}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-all duration-300 ${
                activeLeftTab === 'description'
                  ? 'text-white border-b-2 border-purple-400 bg-white/5'
                  : 'text-purple-200/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Target className="w-4 h-4" />
              Description
            </button>
            <button
              onClick={() => setActiveLeftTab('results')}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-all duration-300 relative ${
                activeLeftTab === 'results'
                  ? 'text-white border-b-2 border-purple-400 bg-white/5'
                  : 'text-purple-200/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              Test Results
              {submissionResults==='ALL_TESTS_PASSED'&&(
                <span className="absolute top-2 right-2 w-2 h-2 bg-pink-500 rounded-full animate-pulse"></span>
              )}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {activeLeftTab === 'description' ? (
              <div className="max-w-3xl">
                <div className="flex items-center gap-2 mb-4">
                  <Target className="w-5 h-5 text-purple-400" />
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                    {problem.title}
                  </h2>
                </div>
                <div className="prose prose-invert prose-purple max-w-none">
                  <p className="text-purple-100/80 whitespace-pre-wrap leading-relaxed text-sm">
                    {problem.description}
                  </p>
                </div>
              </div>
            ) : (
              <div className="max-w-3xl">
                <div className="flex items-center gap-2 mb-4">
                  <Award className="w-5 h-5 text-purple-400" />
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                    Submission Results
                  </h2>
                </div>
                {submissionResults ? (
                  <div className="space-y-4">
                    {submissionResults==='ALL_TESTS_PASSED' ? (
                      <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-6 backdrop-blur-sm">
                        <div className="flex items-center gap-3 mb-2">
                          <CheckCircle2 className="w-8 h-8 text-green-400" />
                          <h3 className="text-xl font-bold text-green-300">Perfect Score! 🎉</h3>
                        </div>
                        <p className="text-green-200/80 text-sm">All hidden test cases passed successfully!</p>
                      </div>
                    ) : submissionResults.includes('ERROR') ? (
                      <div className="bg-gradient-to-r from-red-500/20 to-pink-500/20 border border-red-500/30 rounded-xl p-6 backdrop-blur-sm">
                        <div className="flex items-center gap-3 mb-2">
                          <XCircle className="w-8 h-8 text-red-400" />
                          <h3 className="text-xl font-bold text-red-300">Submission Error</h3>
                        </div>
                        <p className="text-red-200/80 text-sm">There was an error processing your submission.</p>
                      </div>
                    ) : (
                      <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-xl p-6 backdrop-blur-sm">
                        <div className="flex items-center gap-3 mb-2">
                          <XCircle className="w-8 h-8 text-yellow-400" />
                          <h3 className="text-xl font-bold text-yellow-300">Some Tests Failed</h3>
                        </div>
                        <p className="text-yellow-200/80 text-sm">Review the results below to see which test cases failed.</p>
                      </div>
                    )}

                    <div className="bg-slate-950/50 border border-white/10 rounded-xl p-4 backdrop-blur-sm">
                      <h4 className="text-sm font-semibold text-purple-300 mb-3 flex items-center gap-2">
                        <Terminal className="w-4 h-4" />
                        Detailed Output
                      </h4>
                      <pre className="whitespace-pre-wrap font-mono text-xs text-purple-100/90 leading-relaxed">
                        {submissionResults}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FlaskConical className="w-12 h-12 text-purple-400/40 mx-auto mb-3" />
                    <p className="text-purple-200/60 text-sm">No submission results yet</p>
                    <p className="text-purple-200/40 text-xs mt-1">Click Submit to run hidden test cases</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div
          className="absolute top-0 bottom-0 w-1 cursor-col-resize bg-gradient-to-b from-purple-500/40 via-pink-500/40 to-purple-500/40 hover:w-1.5 transition-all group z-20"
          style={{ left: `${leftWidth}%` }}
          onMouseDown={() => setIsDragging(true)}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-purple-400 to-pink-400 opacity-0 group-hover:opacity-100 blur transition-opacity"></div>
        </div>

        <div ref={rightPanelRef} className="flex flex-col relative" style={{ width: `${100 - leftWidth}%` }}>
          <div className="flex-shrink-0 bg-white/5 backdrop-blur-sm border-b border-white/10 px-4 py-2 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-purple-400" />
            <span className="text-xs font-medium text-purple-200/80">Code Editor</span>
            <div className="ml-auto flex gap-1">
              <div className="w-2 h-2 rounded-full bg-red-400/60"></div>
              <div className="w-2 h-2 rounded-full bg-yellow-400/60"></div>
              <div className="w-2 h-2 rounded-full bg-green-400/60"></div>
            </div>
          </div>

          <textarea
            value={code}
            onChange={e => setCode(e.target.value)}
            className="flex-1 bg-slate-950/90 p-4 font-mono text-sm text-emerald-300 focus:outline-none resize-none leading-relaxed"
            style={{ height: testResults ? `${100 - resultsHeight}%` : 'calc(100% - 40px)' }}
            spellCheck="false"
          />

          {testResults && (
            <>
              <div
                className="h-1 cursor-row-resize bg-gradient-to-r from-purple-500/40 via-pink-500/40 to-purple-500/40 hover:h-1.5 transition-all group relative z-20"
                onMouseDown={() => setIsDraggingVertical(true)}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-pink-400 opacity-0 group-hover:opacity-100 blur transition-opacity"></div>
              </div>
              
              <div
                className="bg-slate-950/95 backdrop-blur-sm overflow-y-auto border-t border-white/10"
                style={{ height: `${resultsHeight}%` }}
              >
                <div className="flex items-center gap-2 px-4 py-2 bg-white/5 border-b border-white/10">
                  <Terminal className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-medium text-purple-200/80">Sample Test Results (Run)</span>
                </div>
                <div className="p-4">
                  <pre className="whitespace-pre-wrap font-mono text-xs text-purple-100/90 leading-relaxed">
                    {testResults}
                  </pre>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <style>{`
        * {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        *::-webkit-scrollbar {
          display: none;
        }
        textarea {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        textarea::-webkit-scrollbar {
          display: none;
        }
        
        @keyframes float {
          0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(-100vh) rotate(360deg);
            opacity: 0;
          }
        }
        
        .animate-float {
          animation: float linear infinite;
          font-size: 2rem;
        }
      `}</style>
    </div>
  )
}